public class Character extends Entity
{
    Character(String name, String description)
    {
        super(name, description,  "character");
    }
}
