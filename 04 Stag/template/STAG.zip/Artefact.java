
public class Artefact extends Entity
{
    Artefact(String name, String description)
    {
        super(name, description, "artefact");
    }
}
