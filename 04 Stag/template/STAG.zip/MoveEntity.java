public interface MoveEntity {

    void addEntity(Entity newEntity);
    void removeEntity(String name);

}
