public class Health extends Entity {
    Health(String name, String description)
    {
        super(name, description,  "health");
    }
}
