public class Furniture extends Entity
{

    Furniture(String name, String description)
    {
        super(name, description, "furniture");

    }
}